from flask import Flask, make_response, jsonify, request
app = Flask(__name__)
PORT = 3200
INFO = {
    "Courses":{
        "Course1":"Java",
        "Course2":"Python",
        "Course3":"Go"
    },
    "Books":{
        "Book1":"Java basics",
        "Book2":"Python fundamentals",
        "Book3":"Go basics"
    },
    "Schools":{
        "Sc1":"School1",
        "Sc2":"School2",
        "Sc3":"School3"
    }
}

# Get all data from json object
@app.route("/json")
def allJson():
    res = make_response(jsonify(INFO), 200)
    return res

#Add new course and new school
@app.route("/json/<collection>/<member>", methods=["POST"])
def addMem(collection, member):
    req = request.get_json()
    if member in INFO[collection]:
       res = make_response(jsonify({"error":"the item is already exist"}), 404)
       return res
    INFO[collection].update(req)
    res = make_response(jsonify({"sucess":"member is added"}), 200)
    return res
     

#Edit School Name
@app.route("/json/<collection>/<member>", methods=["PUT"])
def editMem(collection, member):
    req = request.get_json()
    if collection in INFO:
        print(req)
        INFO[collection][member]=req["new"]
        res = make_response(jsonify({"res":INFO[collection]}), 200)
        return res
    res = make_response(jsonify({"error":"not found"}), 404)
    return res

# delete Book
@app.route("/json/<collection>/<member>", methods=["DELETE"])
def delMem(collection, member):
    if member in INFO[collection]:
        del INFO[collection][member]
        res = make_response(jsonify(INFO[collection]), 200)
        return res
    res = make_response(jsonify({"error":"not found"}), 404)
    return res


if __name__ == "__main__":
    print("Server is running in port %s"%(PORT))
    app.run(host='Localhost', port=PORT)